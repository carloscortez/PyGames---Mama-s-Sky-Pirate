

#2 PLAYER GAME CONTROL WITH ARROW
#JOLLY CORP.
#CARLOS CORTEZ - BRANDON ACKERMAN - JOLYON BURGESS
from gamelib import*
#objects Owowowowowoow
game = Game(626,626,"Mama's Sky Pirate")
title = Image("title.jpg",game)
bk=Image("background234.jpg",game)
snake=Animation("monster_gorgon_magic1.png",9,game,500/9,62)
littleboy=Animation("1.png",10,game,548/10,50)
swordguy=Animation("skelefix.png",9,game,363/9,46)
swordguyattack=Image("monster_skeleton_sword.png",game)
swordguyattack.moveTo(swordguy.x,swordguy.y)
snakeattack=Image("monster_gorgon_magic_attack1.png",game)
littleboy.resizeBy(100)
swordguy.resizeBy(200)
swordguy.moveTo(100,410)
snake.resizeBy(150)
snake.moveTo(500,410)
snakeattack.resizeBy(150)
game.setBackground(bk)

swordguyattack.resizeBy(200)
endscreen=Image("end screen.gif",game)
logo=Image("yolologo.jpg",game)
snakeattack.visible=False
#gameloop wowowoOWOWOWO so neccesary, i love having to comment everything
#title screen
while not game.over:
    game.processInput()
    title.draw()
    logo.draw()
    game.update(60)
    game.drawText("P R E S S   S P A C E   T O   S T A R T",185,17)
    game.drawText("To control the Skeleton, use A and D, to attack press the Left Shift. To control",15,580)
    game.drawText("the Python(ha get it) use the Left and Right arrows,",120,595)
    game.drawText("to attack use the Right Shift",180,610)
    if keys.Pressed[K_SPACE]:
        game.over=True       
game.over = False
while not game.over:
#if statements just in case you forgot what they look like ;)
    if keys.Pressed[K_d]:
        swordguy.x+=20
    if keys.Pressed[K_a]:
        swordguy.x-=20
    if keys.Pressed[K_RIGHT]:
        snake.x+=20
    if keys.Pressed[K_LEFT]:
        snake.x-=20
    if not keys.Pressed[K_RSHIFT]:
        snakeattack.visible=False
        snake.visible=True
    if keys.Pressed[K_RSHIFT]:
        snakeattack.visible=True
        snake.visible=False
    if snakeattack.collidedWith(swordguy):
        swordguy.health-=3
        snake.visible=False
    if not keys.Pressed[K_LSHIFT]:
        swordguyattack.visible=False
        swordguy.visible=True
    if keys.Pressed[K_LSHIFT]:
        swordguyattack.visible=True
        swordguy.visible=False
    if swordguyattack.collidedWith(snake):
        snake.health-=3
    game.scrollBackground("left",5)
    game.processInput()
    swordguyattack.moveTo(swordguy.x,swordguy.y)
    snakeattack.moveTo(snake.x,snake.y)
    swordguy.draw()
    snakeattack.draw()
    swordguyattack.draw()
    snake.draw()
    game.drawText("Health: " + str(snake.health), snake.x-20, snake.y+75)
    game.drawText("Health: " + str(swordguy.health), swordguy.x-60, swordguy.y+75)
    game.update(30)
    if snake.health<1:
        game.over=True        
    if swordguy.health<1:
        game.over=True
game.over=False
while not game.over:
    endscreen.draw()
    game.update(60)
    game.processInput()
    game.clearBackground()
    game.drawText("G A M E   O V E R",260,60)
    game.drawText("P R E S S    E S C A P E    T O    Q U I T",185,565)
    if keys.Pressed[K_ESCAPE]:
        game.over=True
game.quit()

    
                        
    
    




